extends Node2D


var plant_scene: PackedScene = preload("res://scenes/objects/plant.tscn")
@onready var player: CharacterBody2D = $Objects/Player
@export var daytime_gradient: Gradient

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	var daytime_point: float = 1 - $DayTimer.time_left / $DayTimer.wait_time
	$CanvasModulate.color = daytime_gradient.sample(daytime_point)
	pass
	if Input.is_action_just_pressed("ui_focus_next"):
		day_switch()

func _on_player_tool_use(tool: int, pos: Vector2) -> void:
	var grid_pos = Vector2i(int(pos.x / 16), int(pos.y / 16))
	if tool == player.Tools.HOE:
		var cell = $Layers/GrassLayer.get_cell_tile_data(grid_pos) as TileData
		if cell and cell.get_custom_data("usable"):
			$Layers/SoilLayer.set_cells_terrain_connect([grid_pos], 0, 0)
		
	elif tool == player.Tools.AXE:
		print("axe")
		
	else:
		var cell = $Layers/SoilLayer.get_cell_tile_data(grid_pos) as TileData
		if cell:
			$Layers/SoilWaterLayer.set_cell(grid_pos, 0, Vector2i(randi_range(0, 2), 0))
			


func _on_player_seed_use(seed_enum: int, pos: Vector2) -> void:
	var grid_pos = Vector2i(int(pos.x / 16), int(pos.y / 16))
	var cell = $Layers/SoilLayer.get_cell_tile_data(grid_pos) as TileData
	if cell:
		var plant_pos: Vector2 = Vector2(grid_pos.x * 16 + 7, grid_pos.y * 16 - 5)
		var plant = plant_scene.instantiate() as StaticBody2D
		plant.setup(seed_enum, grid_pos)
		$Objects.add_child(plant)
		plant.position = plant_pos


func day_switch() -> void:
	var tween = create_tween()
	tween.tween_property($CanvasLayer/ColorRect, "modulate:a", 1.0, 1.0)
	tween.tween_callback(level_reset)
	tween.tween_interval(1.0)
	tween.tween_property($CanvasLayer/ColorRect, "modulate:a", 0.0, 1.0)
	

func level_reset() -> void:
	for plant in get_tree().get_nodes_in_group("Plants"):
		var cell = $Layers/SoilWaterLayer.get_cell_tile_data(plant.grid_position) as TileData
		if true:
			plant.grow(true)
			
		else:
			plant.grow(false)
			
	$Layers/SoilWaterLayer.clear()
	$DayTimer.start()
