extends StaticBody2D


var grid_position: Vector2
var max_age: int
var grow_speed: float
var age: float
const PLANT_DATA = {
	Global.Seeds.CORN: {'texture': preload("res://graphics/plants/corn.png"), "max_age": 3, "grow_speed": 0.6},
	Global.Seeds.TOMATO: {'texture': preload("res://graphics/plants/tomatoes.png"), "max_age": 3, "grow_speed": 0.8},
	Global.Seeds.PUMPKIN: {'texture': preload("res://graphics/plants/pumpkin.png"), "max_age": 3, "grow_speed": 0.6}
}

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func setup(seed_enum: Global.Seeds, grid_pos: Vector2) -> void:
	var plant = PLANT_DATA[seed_enum]
	max_age = plant["max_age"]
	grow_speed = plant["grow_speed"]
	$Sprite2D.texture = plant["texture"]
	grid_position = grid_pos


func grow(watered: bool) -> void:
	if watered:
		age = min(age + grow_speed, max_age)
		$Sprite2D.frame = int(age)


func _on_harvest_plant_body_entered(_body: Node2D) -> void:
	if age >= max_age:
		queue_free()
