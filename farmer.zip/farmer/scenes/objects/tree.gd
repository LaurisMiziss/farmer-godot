extends StaticBody2D


var hp: int = 3


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Sprite2D.frame = randi_range(0, 1)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func take_hit() -> void:
	hp -= 1
	var tween = create_tween()
	tween.tween_property($Sprite2D.material, "shader_parameter/progress", 1.0, 0.2)
	tween.tween_property($Sprite2D.material, "shader_parameter/progress", 0.0, 0.4)

	
	if hp <= 0:
		queue_free()
