extends CharacterBody2D


@onready var move_state_machine: AnimationNodeStateMachinePlayback = $AnimationTree.get("parameters/MoveStateMachine/playback")
@onready var tool_state_machine: AnimationNodeStateMachinePlayback = $AnimationTree.get("parameters/ToolStateMachine/playback")
var can_move: bool = true
const SPEED: float = 150.0
const JUMP_VELOCITY = -400.0
var direction: Vector2
enum Tools {HOE, AXE, WATER}
var current_tool: Tools = Tools.AXE
const tool_connection = {
	Tools.HOE: 'hoe',
	Tools.AXE: 'axe',
	Tools.WATER: 'water'
}
var last_direction: Vector2 = Vector2.ZERO
var tool_direction_offset := 14
var tool_y_offset := 4
signal tool_use(tool: Tools, pos: Vector2)
@onready var hitbox: Area2D = $Hitbox
var current_seed: Global.Seeds = Global.Seeds.CORN
signal seed_use(seed_enum: Global.Seeds, pos: Vector2)

func _ready() -> void:
	hitbox.monitoring = false

func _physics_process(_delta: float) -> void:
	if can_move:
		
		if direction:
			last_direction = direction
			if $StepAudioStreamPlayer2D.playing == false:
				$StepAudioStreamPlayer2D.play()
			
		get_input()
		velocity = direction * SPEED
		move_and_slide()
		animation()

# handling of tools should be done in other func
func get_input() -> void:
	direction = Input.get_vector("left", "right", "up", "down")
	
	if Input.is_action_just_pressed("action"):
		tool_state_machine.travel(tool_connection[current_tool])
		$AnimationTree.set("parameters/OneShot/request", AnimationNodeOneShot.ONE_SHOT_REQUEST_FIRE)
		if current_tool in [Tools.HOE, Tools.WATER]:
			await $AnimationTree.animation_finished
			tool_use.emit(current_tool, global_position + tool_direction_offset * last_direction + Vector2(0, tool_y_offset))
		
	if Input.is_action_just_pressed("tool_forward") or Input.is_action_just_pressed("tool_backward"):
		var switch_dir = round(Input.get_axis("tool_backward", "tool_forward")) as int
		current_tool = posmod(current_tool + switch_dir, Tools.size()) as Tools

	if Input.is_action_just_pressed("seed_toggle"):
		current_seed = posmod(current_seed + 1, Global.Seeds.size()) as Global.Seeds
		
	if Input.is_action_just_pressed("plant"):
		can_move = false
		direction = Vector2.ZERO
		seed_use.emit(current_seed,  global_position + tool_direction_offset * last_direction + Vector2(0, tool_y_offset))
		await get_tree().create_timer(0.5).timeout
		can_move = true
		
func animation() -> void:
	var target_vector: Vector2 = Vector2(round(direction.x), round(direction.y))

	if direction:
		move_state_machine.travel("Walk")
		$AnimationTree.set("parameters/MoveStateMachine/Walk/blend_position", target_vector)
		$AnimationTree.set("parameters/MoveStateMachine/Idle/blend_position", target_vector)
		for state in tool_connection.values():
			$AnimationTree.set("parameters/ToolStateMachine/" + state + "/blend_position", target_vector)

	else:
		move_state_machine.travel("Idle")		


func _on_animation_tree_animation_started(anim_name: StringName) -> void:
	const STOP_ANIM_LIST = ["axe", "hoe", "water"]
	
	for word in STOP_ANIM_LIST:
		if anim_name.contains(word):
			can_move = false
			await $AnimationTree.animation_finished
			can_move = true
			break
			

func axe_use() -> void:
	hitbox.monitoring = true


func axe_unuse() ->void:
	hitbox.monitoring = false


func _on_hitbox_area_entered(hurtbox_area: Area2D) -> void:
	$AxeAudioStreamPlayer2D.play()
	var tree = hurtbox_area.get_parent()
	tree.take_hit()


func play_hoe_sound() -> void:
	$HoeAudioStreamPlayer2D.play()


func play_water_sound() -> void:
	$WaterAudioStreamPlayer2D.play()
